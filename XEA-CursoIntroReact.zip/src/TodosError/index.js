import React from 'react';

function TodosError() {
    return <p> Desafortunadamente, hubo un error...!</p>
}

export { TodosError };

