import React from 'react';

function EmptyTodos() {
    return <p> Crea tu primera TAREA!</p>
}

export { EmptyTodos };